from django.apps import AppConfig


class ExeceptionToTeamsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exeception_to_teams'
